connectors
====================================

.. automodule:: bno055.connectors.Connector
    :members:
    :show-inheritance:

.. automodule:: bno055.connectors.uart
    :members:
    :show-inheritance:

.. automodule:: bno055.connectors.i2c
    :members:
    :show-inheritance:

