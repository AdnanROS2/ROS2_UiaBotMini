import rclpy
from rclpy.node import Node
from tf2_ros import StaticTransformBroadcaster
from geometry_msgs.msg import TransformStamped

class LidarTransformPublisher(Node):
    def __init__(self):
        super().__init__('lidar_transform_publisher')

        # Initialize the static transform broadcaster
        self.static_broadcaster = StaticTransformBroadcaster(self)

        # Create the static transform between base_link and laser_frame
        static_transform = TransformStamped()
        static_transform.header.stamp = self.get_clock().now().to_msg()
        static_transform.header.frame_id = 'base_link'  # Parent frame
        static_transform.child_frame_id = 'laser_frame'  # Child frame for the LiDAR

        # Define the transform: Adjust these values as necessary
        static_transform.transform.translation.x = 0.1  # X offset from base_link
        static_transform.transform.translation.y = 0.0  # Y offset from base_link
        static_transform.transform.translation.z = 0.2  # Z offset from base_link

        # Orientation as a quaternion (no rotation in this case)
        static_transform.transform.rotation.x = 1.0
        static_transform.transform.rotation.y = 0.0
        static_transform.transform.rotation.z = 0.0
        static_transform.transform.rotation.w = 1.0

        # Broadcast the static transform
        self.static_broadcaster.sendTransform(static_transform)
        self.get_logger().info("Broadcasted static transform between base_link and laser_frame")

def main(args=None):
    rclpy.init(args=args)
    lidar_transform_publisher = LidarTransformPublisher()
    try:
        rclpy.spin(lidar_transform_publisher)
    except KeyboardInterrupt:
        lidar_transform_publisher.get_logger().info("LidarTransformPublisher node shutting down.")
    finally:
        lidar_transform_publisher.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

