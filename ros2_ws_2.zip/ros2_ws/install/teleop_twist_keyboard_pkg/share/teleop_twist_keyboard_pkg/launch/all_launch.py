from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node
from launch.substitutions import Command

def generate_launch_description():
    return LaunchDescription([

        # Robot State Publisher Node (for URDF)
	Node(
	    package='robot_publisher_pkg',
	    executable='robot_publisher',
	    name='robot_publisher',
	    output='screen',
	    parameters=[{'robot_description': open('/home/user/ros2_ws/src/robot_publisher_pkg/urdf/robot_model.urdf').read()}]
	),

        # RViz2 Node (for visualization)
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            output='screen',
            arguments=['-d', '/home/user/ros2_ws/src/robot_publisher_pkg/urdf/config.rviz']
        ),

        # Teleop Twist Keyboard Node
	Node(
	    package='teleop_twist_keyboard_pkg',
	    executable='teleop_twist_keyboard',
	    name='teleop_twist_keyboard',
	    output='screen',
	    prefix=['xterm -e'],  # This opens teleop in a new xterm window
	),
	
	 # LiDAR node
        Node(
            package='sllidar_ros2',
            executable='sllidar_node',
            name='sllidar_node',
            output='screen',
            parameters=[
                {'serial_port': '/dev/ttyUSB0'},  # Adjust if LiDAR is on another port
                {'serial_baudrate': 256000},     # Default baudrate for RPLiDAR A1/A2
                {'frame_id': 'laser_frame'},     # Frame ID for the LiDAR scans
                {'inverted': False},            # Whether the LiDAR is mounted inverted
                {'angle_compensate': True}      # Angle compensation for better scan resolution
            ],
        ),
    ])

