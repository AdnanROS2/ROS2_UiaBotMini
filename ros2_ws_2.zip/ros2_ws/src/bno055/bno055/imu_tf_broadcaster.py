import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped
import math


class IMUTFBroadcaster(Node):
    def __init__(self):
        super().__init__('imu_tf_broadcaster')
        # Subscribe to the IMU topic
        self.subscription = self.create_subscription(
            Imu,
            '/bno055/imu',  # IMU topic name
            self.imu_callback,
            10
        )
        # TF Broadcaster
        self.tf_broadcaster = TransformBroadcaster(self)

    def imu_callback(self, msg: Imu):
        # Create a TransformStamped message
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = 'world'  # Parent frame (fixed frame in RViz)
        t.child_frame_id = 'base_link'  # Robot's base frame

        # Extract orientation from the IMU message
        t.transform.rotation.x = msg.orientation.x
        t.transform.rotation.y = msg.orientation.y
        t.transform.rotation.z = msg.orientation.z
        t.transform.rotation.w = msg.orientation.w

        # Publish the transform
        self.tf_broadcaster.sendTransform(t)


def main(args=None):
    rclpy.init(args=args)
    node = IMUTFBroadcaster()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

