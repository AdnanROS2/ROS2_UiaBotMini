from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess
import os

def generate_launch_description():
    # Path to the robot_localization config file
    config_file_path = os.path.join(
        os.path.dirname(__file__), 'src', 'robot_localization_pkg', 'config', 'ekf_config.yaml')

    # Path to an RViz config file, if you have one (optional)
    rviz_config_file = os.path.join(
        os.path.dirname(__file__), 'src', 'robot_localization_pkg', 'config', 'default.rviz')

    return LaunchDescription([
        # Robot Localization Node
        Node(
            package='robot_localization',
            executable='ekf_node',
            name='ekf_filter_node',
            output='screen',
            parameters=[config_file_path]
        ),

        # LiDAR Nodes
        Node(
            package='lidar_package',
            executable='lidar_transform_publisher',
            name='lidar_transform_publisher',
            output='screen'
        ),
        Node(
            package='lidar_package',
            executable='lidar_publisher',
            name='lidar_simulator',
            output='screen'
        ),

        # IMU Nodes
        Node(
            package='imu_packages_pkg',
            executable='imu_publisher',
            name='imu_publisher',
            output='screen'
        ),
        Node(
            package='imu_packages_pkg',
            executable='imu_broadcaster',
            name='imu_broadcaster',
            output='screen'
        ),
        
        # ODO Node
        Node(
            package='odometry_pkg',
            executable='odometry_node',
            name='odometry_node',
            output='screen'
        ),

        # SLAM Toolbox Node
        Node(
            package='slam_toolbox',
            executable='sync_slam_toolbox_node',
            name='slam_toolbox',
            output='screen',
            parameters=[{
                'use_sim_time': False,
                'odom_frame': 'odom',
                'map_frame': 'map',
                'base_frame': 'base_link',
                'scan_topic': '/scan',
                'mode': 'mapping'
            }]
        ),

        # RViz2 Node (will load the specified RViz configuration file if provided)
        ExecuteProcess(
            cmd=['rviz2', '-d', rviz_config_file],
            output='screen'
        ),
    ])

