from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='lidar_package',
            executable='lidar_transform_publisher',
            name='lidar_transform_publisher',
            output='screen'
        ),
        Node(
            package='lidar_package',
            executable='lidar_publisher',
            name='lidar_simulator',
            output='screen'
        ),
    ])

