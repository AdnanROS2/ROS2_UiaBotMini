params
====================================

.. automodule:: bno055.params.NodeParameters
    :members:
