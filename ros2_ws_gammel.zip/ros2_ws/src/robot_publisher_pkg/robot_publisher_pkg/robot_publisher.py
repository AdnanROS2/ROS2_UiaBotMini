import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class RobotPublisher(Node):
    def __init__(self):
        super().__init__('robot_publisher')
        
        # Publisher for cmd_vel
        self.publisher_ = self.create_publisher(Twist, 'cmd_vel', 10)
        
        # Timer to publish at 0.5-second intervals (2 Hz)
        self.timer = self.create_timer(0.5, self.timer_callback)
        
        # Define linear velocity for the message
        self.linear_speed = 0.1  # Example linear speed (m/s)
        self.get_logger().info("RobotPublisher initialized. Publishing linear velocity commands.")

    def timer_callback(self):
        # Create and publish Twist message
        msg = Twist()
        msg.linear.x = self.linear_speed
        msg.angular.z = 0.0  # No rotation
        
        self.publisher_.publish(msg)
        self.get_logger().info(f'Publishing linear velocity: {msg.linear.x} m/s')  # Correctly closed f-string

def main(args=None):
    rclpy.init(args=args)
    robot_publisher = RobotPublisher()
    
    try:
        rclpy.spin(robot_publisher)
    except KeyboardInterrupt:
        robot_publisher.get_logger().info("Shutting down RobotPublisher due to user interrupt.")
    finally:
        robot_publisher.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

