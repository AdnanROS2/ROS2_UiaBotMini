from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess
import os

def generate_launch_description():
    # Path to the robot_localization config file
    config_file_path = os.path.join(
        os.path.dirname(__file__), 'src', 'robot_localization_pkg', 'config', 'ekf_config.yaml')

    # Path to an RViz config file, if you have one (optional)
    rviz_config_file = os.path.join(
        os.path.dirname(__file__), 'src', 'robot_localization_pkg', 'config', 'default.rviz')

    return LaunchDescription([

        # SLAM Toolbox Node
        Node(
            package='slam_toolbox',
            executable='sync_slam_toolbox_node',
            name='slam_toolbox',
            output='screen',
            parameters=[{
                'use_sim_time': False,
                'odom_frame': 'odom',
                'map_frame': 'map',
                'base_frame': 'base_link',
                'scan_topic': '/scan',
                'mode': 'mapping'
            }]
        ),

        # RViz2 Node (will load the specified RViz configuration file if provided)
        ExecuteProcess(
            cmd=['rviz2', '-d', rviz_config_file],
            output='screen'
        ),
        
        Node(
            package='teleop_twist_keyboard_pkg',
            executable='teleop_twist_keyboard',
            name='teleop_twist_keyboard',
            output='screen'
        ),
    ])

