.. bno055 documentation master file, created by
   sphinx-quickstart on Mon Feb  8 19:58:23 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome
==================================

A ROS2 driver for the sensor IMU Bosch BNO055.

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   bno055
   connectors
   error_handling
   params
   sensor
   registers 

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
