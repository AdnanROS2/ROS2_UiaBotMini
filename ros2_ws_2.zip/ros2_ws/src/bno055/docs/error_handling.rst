error_handling
====================================

.. automodule:: bno055.error_handling.exceptions
    :members:
