registers
====================================

.. automodule:: bno055.registers
    :members:
