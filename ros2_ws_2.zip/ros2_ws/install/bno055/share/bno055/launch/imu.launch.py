from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # IMU Node
        Node(
            package='bno055',
            executable='bno055',
            name='bno055',
            output='screen',
            parameters=[{
                "i2c_address": 0x28,  # Update this if your IMU uses a different address
                "frame_id": "imu_link"  # The frame in which the IMU publishes
            }],
        ),
        # IMU TF Broadcaster Node
        Node(
            package='bno055',
            executable='imu_tf_broadcaster',
            name='imu_tf_broadcaster',
            output='screen',
        ),
    ])

