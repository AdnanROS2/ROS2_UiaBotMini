import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
import math
import random

class LidarSimulator(Node):
    def __init__(self):
        super().__init__('lidar_simulator')
        self.publisher_ = self.create_publisher(LaserScan, '/scan', 10)
        self.timer = self.create_timer(0.1, self.publish_scan)  # 10 Hz

    def publish_scan(self):
        scan_msg = LaserScan()
        scan_msg.header.stamp = self.get_clock().now().to_msg()
        scan_msg.header.frame_id = 'laser_frame'
        scan_msg.angle_min = -math.pi / 4  # -45 degrees
        scan_msg.angle_max = math.pi / 4   # 45 degrees
        scan_msg.angle_increment = math.radians(1)
        scan_msg.range_min = 0.2  # Minimum range of LiDAR
        scan_msg.range_max = 10.0  # Maximum range of LiDAR

        # Simulate random distance measurements within range
        scan_msg.ranges = [random.uniform(scan_msg.range_min, scan_msg.range_max) for _ in range(int((scan_msg.angle_max - scan_msg.angle_min) / scan_msg.angle_increment))]
        
        self.publisher_.publish(scan_msg)

def main(args=None):
    rclpy.init(args=args)
    lidar_simulator = LidarSimulator()
    try:
        rclpy.spin(lidar_simulator)
    except KeyboardInterrupt:
        lidar_simulator.get_logger().info("LiDAR simulator shutting down.")
    finally:
        lidar_simulator.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

