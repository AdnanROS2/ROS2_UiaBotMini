import serial
import struct
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import JointState

class VelocitySubscriber(Node):
    def __init__(self):
        super().__init__('velocity_subscriber')

        self.subscription = self.create_subscription(Twist, '/cmd_vel', self.listener_callback, 10)
        self.joint_state_publisher = self.create_publisher(JointState, '/joint_states', 10)

        self.left_wheel_velocity = 0.0
        self.right_wheel_velocity = 0.0
        self.left_wheel_position = 0.0
        self.right_wheel_position = 0.0

        try:
            self.ser = serial.Serial('/dev/ttyUSB0', baudrate=115200, timeout=0.1)
            self.get_logger().info("Serial port opened successfully.")
        except serial.SerialException as e:
            self.get_logger().error(f"Error opening serial port: {e}")
            self.ser = None

        self.timer = self.create_timer(0.1, self.read_serial_data)
        self.last_time = self.get_clock().now()

    def listener_callback(self, msg):
        self.linear_velocity = msg.linear.x
        self.angular_velocity = msg.angular.z
        self.get_logger().info(f'Received cmd_vel - linear.x: {self.linear_velocity}, angular.z: {self.angular_velocity}')
        self.send_values(self.linear_velocity, self.angular_velocity)

    def send_values(self, linear_velocity, angular_velocity):
        if self.ser:
            try:
                value_buff = struct.pack('=BBff', 36, 36, linear_velocity, angular_velocity)
                self.ser.write(value_buff)
                self.get_logger().info(f"Sent values to serial: linear_velocity={linear_velocity}, angular_velocity={angular_velocity}")
            except serial.SerialException as e:
                self.get_logger().error(f"Failed to send values: {e}")

    def read_serial_data(self):
        if self.ser:
            try:
                input_data = self.ser.read(40)
                if len(input_data) < 40:
                    return

                headerPos = input_data.find(b'\x24\x24')
                if headerPos == -1:
                    return

                inData = input_data[headerPos + 2:headerPos + 10]
                if len(inData) == 8:
                    v_left, v_right = struct.unpack('=ff', inData)
                    self.publish_joint_states(v_left, v_right)
            except (struct.error, serial.SerialException) as e:
                self.get_logger().error(f"Error reading from serial: {e}")

    def publish_joint_states(self, v_left, v_right):
        current_time = self.get_clock().now()
        dt = (current_time - self.last_time).nanoseconds * 1e-9
        self.last_time = current_time

        self.left_wheel_position += v_left * dt
        self.right_wheel_position += v_right * dt

        joint_state = JointState()
        joint_state.header.stamp = current_time.to_msg()
        joint_state.name = ['left_wheel_joint', 'right_wheel_joint']
        joint_state.position = [self.left_wheel_position, self.right_wheel_position]
        joint_state.velocity = [v_left, v_right]

        self.joint_state_publisher.publish(joint_state)
        self.get_logger().info(f'Publishing joint states - left pos: {self.left_wheel_position}, right pos: {self.right_wheel_position}')

    def close_serial(self):
        if self.ser:
            self.ser.close()
            self.get_logger().info("Serial port closed.")

def main(args=None):
    rclpy.init(args=args)
    velocity_subscriber = VelocitySubscriber()
    try:
        rclpy.spin(velocity_subscriber)
    except KeyboardInterrupt:
        velocity_subscriber.get_logger().info("Shutdown requested by user...")
    finally:
        velocity_subscriber.close_serial()
        velocity_subscriber.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

