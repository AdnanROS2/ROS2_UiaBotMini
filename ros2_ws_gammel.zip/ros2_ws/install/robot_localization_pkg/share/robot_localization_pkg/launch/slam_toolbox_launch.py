from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='slam_toolbox',
            executable='sync_slam_toolbox_node',  # Use synchronous mode for live mapping
            name='slam_toolbox',
            output='screen',
            parameters=[{
                'use_sim_time': False,       # Set to True if using simulation time
                'odom_frame': 'odom',        # Your odometry frame
                'map_frame': 'map',          # Frame for the generated map
                'base_frame': 'base_link',   # Base frame of your robot
                'scan_topic': '/scan',       # LiDAR scan topic
                'mode': 'mapping'            # Set mode to 'mapping' for live mapping
            }]
        ),
    ])

