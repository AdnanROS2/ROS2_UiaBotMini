from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # SLAM Toolbox Node
        Node(
            package='slam_toolbox',
            executable='sync_slam_toolbox_node',  # Synchronous SLAM mode
            name='slam_toolbox',
            output='screen',
            parameters=[
                {'use_sim_time': False},
                {'slam_toolbox_params_file': '/home/user/ros2_ws/src/teleop_twist_keyboard_pkg/config/slam_config.yaml'}
            ],
            remappings=[
                ('scan', '/scan'),  # Replace '/scan' with your LiDAR topic
            ]
        ),

        # RViz2 Node
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            output='screen',
            arguments=['-d', '/path/to/your/rviz/config.rviz']  # Replace with your RViz config file
        ),

        # Teleop Twist Keyboard Node
        Node(
            package='teleop_twist_keyboard_pkg',
            executable='teleop_twist_keyboard',
            name='teleop_twist_keyboard',
            output='screen',
            prefix=['xterm -e'],  # Opens in a new terminal for better interactivity
            remappings=[
                ('cmd_vel', '/cmd_vel')  # Adjust to match your robot's velocity topic
            ],
        ),
    ])

